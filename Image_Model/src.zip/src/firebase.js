import { initializeApp } from "firebase/app";
import {getAuth} from 'firebase/auth'

const firebaseConfig = {
  apiKey: "AIzaSyAPbnyQTbmiFOaxmr0cPHL8ou-rhPkCVyo",
  authDomain: "emonexa-trial-80641.firebaseapp.com",
  projectId: "emonexa-trial-80641",
  storageBucket: "emonexa-trial-80641.appspot.com",
  messagingSenderId: "67531615867",
  appId: "1:67531615867:web:7069869ffb4476d101fcde",
  measurementId: "G-PD2M4XE0YG"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();

export {app,auth};
